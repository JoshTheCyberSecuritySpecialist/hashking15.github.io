---
title: "Post: Video (YouTube)"
categories:
  - Post Formats
tags:
  - Post Formats
---

YouTube video embed below.

<iframe width="640" height="360" src="https://www.youtube-nocookie.com/embed/l2Of1-d5E5o?controls=0&amp;showinfo=0" frameborder="0" allowfullscreen></iframe>