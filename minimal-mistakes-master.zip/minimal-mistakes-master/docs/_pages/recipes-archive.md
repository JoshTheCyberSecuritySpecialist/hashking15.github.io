---
layout: collection
title: "Recipes"
collection: recipes
permalink: /recipes/
author_profile: false
---

Sample document listing for the collection `_recipes`.